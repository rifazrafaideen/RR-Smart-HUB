<?php
echo("Your message is beign sent succesfully")
?>